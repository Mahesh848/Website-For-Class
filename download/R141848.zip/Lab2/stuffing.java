import java.util.*;
class Stuff{
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("\t1.Bytecount\n\t2.BitStuffing:  ");
		System.out.print("Enter your option:   ");
		int opt = in.nextInt();
		if(opt==1){
			String s = new String();
			s = in.next();
			byteCount(s);
		}
		if(opt==2){
			String s = new String();
			s = in.next();
			bitStuffing(s);
		}
	}
	static void byteCount(String str){
		int n = str.length();
		String s1 = Integer.toString(n);
		str = str+s1;
		System.out.println(str);
	}
	static void bitStuffing(String str){
		StringBuilder str1 = new StringBuilder();
		for(int i=0;i<str.length();i++){
			int num = (int)str.charAt(i);
			char s[] = new char[8];
			int s_i=0;
			while(num>0){
				s[s_i++] = (char)((num%2)+48);
				//System.out.print(s[s_i-1]+"  ");
				num = num/2;
			}
			int bal = 8-(s_i);
			for(int j=0;j<bal;j++){
				s[s_i++] = '0';
			}
			for(int j=s_i-1;j>=0;j--){
				str1.append(s[j]);
			}
			//System.out.println(str1);
		}
		int s1_i=0;
		while (s1_i<str1.length()){
			int b = 5;
			int s1_i2 = s1_i;
			while(s1_i2<str1.length() && str1.charAt(s1_i2)!='0' && b>0){
				s1_i2++;b--;
			}
			if(b==0){
				str1.insert(s1_i2,"0");
				//System.out.println(str1);
			}
			if(s1_i==s1_i2){
				s1_i++;
			}
			else{
				s1_i = s1_i2;
			}	
		}
		senReceiver(str1);
	}
	static void senReceiver(StringBuilder str){
		int s1_i=0;
		while (s1_i<str.length()){
			int b = 5;
			int s1_i2 = s1_i;
			while(s1_i2<str.length() && str.charAt(s1_i)!='0' && b>0){
				s1_i2++;b--;
			}
			if(b==0){
				str.delete(s1_i2,s1_i2);
			}
			if(s1_i==s1_i2){
				s1_i++;
			}
			else{
				s1_i = s1_i2;
			}	
		}
		//System.out.println(str);
		String mes = new String();
		int i = str.length()-1;
		while(i>=0){
			int b = 0;
			int num=0;
			while(i>=0 && b<8){
				if(str.charAt(i)=='1'){
					num = num+((int)Math.pow(2,b));
					//System.out.println(num);
					b++;
					i--;
				}
				else{
					b++;
					i--;
				}

			}
			mes  = mes +(char)num;
		}
		StringBuilder mew = new StringBuilder(mes);
		System.out.println(mew.reverse());
	}
}