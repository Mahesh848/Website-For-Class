#include <stdio.h>
#include <string.h>

void fromNL(char *str);

void fromTL(char *str);
	
void fromSL(char *str);
	
void fromPhL(char *str);
	
void fromAL(char *str);
	
void fromDL(char *str);
	
void fromPL(char *str);

void Transform(int *arr,int j);

void toPhL(char *str);

void toDL(char *str);

void toNL(char *str);

void toTL(char *str);

void toSL(char *str);

void toPL(char *str);

void toAL(char *str);

main(){
	char s[1000];
	scanf("%s",s);
	fromAL(s);
}
void fromAL(char *str){
	strcat(str,"AL");
	printf("%s\n",str);
	fromPL(str);
}
void fromPL(char *str){
	strcat(str,"PL");
	printf("%s\n",str);
	fromSL(str);
}
void fromSL(char *str){
	strcat(str,"SL");
	printf("%s\n",str);
	fromTL(str);
}
void fromTL(char *str){
	strcat(str,"TL");
	printf("%s\n",str);
	fromNL(str);
}
void fromNL(char *str){
	strcat(str,"NL");
	printf("%s\n",str);
	fromDL(str);
}
void fromDL(char *str){
	strcat(str,"DL");
	printf("%s\n",str);
	fromPhL(str);
}
void fromPhL(char *str){
	strcat(str,"PL");
	printf("%s\n",str);
	int arr[strlen(str)];
	int i=0;
	for(i=0;i<strlen(str);i++){
		arr[i] = (int)*(str+i);
	}
	Transform(arr,i);	
}
void Transform(int *arr,int j){
	char s[1000];
	char *str = s;
	int i;
	for(i=0;i<j;i++){
		printf("%d  ",*(arr+i));
	}
	printf("\n");
	for(i=0;i<j;i++){
		*(str+i) = (char)arr[i];
	}
	*(str+i+1) = '\0';
	toPhL(str);
}
void toPhL(char *str){
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toDL(str);
}
void toDL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toNL(str);
}
void toNL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toTL(str);
}
void toTL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toSL(str);
}
void toSL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toPL(str);
}
void toPL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
	toAL(str);
}
void toAL(char *str){
	
	int k = strlen(str);
	*(str+k-2) = '\0';
	printf("%s\n",str);
}
